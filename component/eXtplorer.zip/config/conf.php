<?php
if( !defined( '_JEXEC' ) && !defined( '_VALID_MOS' ) ) die( 'Restricted access' );
$GLOBALS['use_gzip'] = 1;
$GLOBALS['ext_conf']['authentication_method_default'] = 'extplorer';
$GLOBALS['ext_conf']['authentication_methods_allowed'] = array('extplorer', 'ftp');
$GLOBALS['ext_conf']['remote_hosts_allowed'] = array('localhost');
$GLOBALS['allow_webdav'] = 0;
$GLOBALS['webdav_authentication_method'] = 'extplorer'; 
$GLOBALS['DB_HOST'] = 'localhost';
$GLOBALS['DB_NAME'] = 'webdav';
$GLOBALS['DB_USER'] = 'root';
$GLOBALS['DB_PASSWORD'] = '';
$GLOBALS['DB_TYPE'] = 'mysql'; 
$GLOBALS["show_hidden"] = true;
$GLOBALS["no_access"] = ''; 
$GLOBALS["permissions"] = 7;
$GLOBALS["use_mb"] = FALSE;
if (extension_loaded('mbstring')) {
	$GLOBALS["use_mb"] = TRUE;
}
$GLOBALS["system_charset"] = 'UTF-8';
setlocale(LC_ALL, 'en_US.UTF8');
$GLOBALS['ext_conf']['symlink_allow_abovehome'] = FALSE;