DROP TABLE IF EXISTS `#__extwebdav_locks`;
DROP TABLE IF EXISTS `#__extwebdav_properties`;